import os
import json
import urllib.parse
import urllib.request

NOMINATIM_URL = "https://nominatim.openstreetmap.org"
USER_AGENT = "QuickTIMS/1.0 (field-service; caldimengg@gmail.com)"


def detect_customer_location(latitude: float, longitude: float, accuracy: float = None) -> dict | None:
    """
    Stateless reverse geocoding of GPS coordinates (lat, lng) to structured location:
      latitude, longitude, accuracy, area, city, state, country, pincode, formatted_address.
    
    No database/Django persistence dependencies (stateless, pure Python standard libraries).
    Returns None if reverse geocoding fails.
    """
    try:
        lat = float(latitude)
        lng = float(longitude)
    except (ValueError, TypeError):
        raise ValueError("Invalid latitude or longitude coordinates.")

    if not (-90.0 <= lat <= 90.0) or not (-180.0 <= lng <= 180.0):
        raise ValueError("Invalid latitude or longitude coordinates.")

    acc = None
    if accuracy is not None:
        try:
            acc = float(accuracy)
        except (ValueError, TypeError):
            pass

    # Read from environment, fallback to the provided CalTrack key
    google_api_key = os.environ.get("GOOGLE_MAPS_API_KEY") or os.environ.get("VITE_GOOGLE_MAPS_KEY") or "AIzaSyC-7JjgSXDrqNF1BMMnlvKtgRPS6_98uP8"
    
    if google_api_key:
        try:
            g_url = f"https://maps.googleapis.com/maps/api/geocode/json?latlng={lat},{lng}&key={google_api_key}"
            req = urllib.request.Request(g_url, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=5) as resp:
                g_data = json.loads(resp.read())
            
            if g_data.get("status") == "OK" and g_data.get("results"):
                first = g_data["results"][0]
                comps = first.get("address_components", [])
                
                sublocality = ""
                route = ""
                city = ""
                state = ""
                pincode = ""
                country = ""

                for c in comps:
                    types = c.get("types", [])
                    if "sublocality" in types or "sublocality_level_1" in types:
                        sublocality = c.get("long_name", "")
                    if "route" in types:
                        route = c.get("long_name", "")
                    if "locality" in types:
                        city = c.get("long_name", "")
                    if "administrative_area_level_1" in types:
                        state = c.get("long_name", "")
                    if "postal_code" in types:
                        pincode = c.get("long_name", "")
                    if "country" in types:
                        country = c.get("long_name", "")

                area = ", ".join(filter(None, [sublocality, route])) or sublocality or route or "Current Location"
                return {
                    "latitude": lat,
                    "longitude": lng,
                    "accuracy": acc,
                    "area": area,
                    "city": city,
                    "state": state,
                    "country": country or "India",
                    "pincode": pincode,
                    "formatted_address": first.get("formatted_address", ""),
                }
        except Exception:
            pass

    # Fallback to OpenStreetMap/Nominatim
    try:
        encoded = urllib.parse.urlencode({
            "lat": lat,
            "lon": lng,
            "format": "json",
            "addressdetails": "1",
            "accept-language": "en"
        })
        req = urllib.request.Request(
            f"{NOMINATIM_URL}/reverse?{encoded}",
            headers={"User-Agent": USER_AGENT, "Accept-Language": "en"}
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())

        if not data:
            return None

        addr = data.get("address", {})
        raw_area_parts = [
            addr.get("building"),
            addr.get("house_number"),
            addr.get("road"),
            addr.get("suburb"),
            addr.get("neighbourhood"),
            addr.get("residential"),
            addr.get("city_district"),
        ]
        clean_parts = []
        for p in raw_area_parts:
            if p and p not in clean_parts:
                clean_parts.append(p)

        area = ", ".join(clean_parts[:2]) if clean_parts else (
            addr.get("suburb") or addr.get("neighbourhood") or addr.get("city_district") or ""
        )
        city = (
            addr.get("city")
            or addr.get("town")
            or addr.get("village")
            or addr.get("county")
            or ""
        )
        state = addr.get("state", "")
        country = addr.get("country", "")
        pincode = addr.get("postcode", "")
        formatted_address = data.get("display_name", "")

        return {
            "latitude": lat,
            "longitude": lng,
            "accuracy": acc,
            "area": area,
            "city": city,
            "state": state,
            "country": country or "India",
            "pincode": pincode,
            "formatted_address": formatted_address,
        }
    except Exception:
        return None


# Simple inline test snippet when executed directly
if __name__ == "__main__":
    # Test coordinates (e.g. Hosur, India)
    test_lat, test_lng = 12.7409, 77.8253
    print(f"Testing geocoder for coordinates: ({test_lat}, {test_lng})...")
    res = detect_customer_location(test_lat, test_lng)
    print(json.dumps(res, indent=2))
