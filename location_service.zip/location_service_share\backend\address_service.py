"""
AddressService — address-related business logic for the customer address picker.

This Django service:
  - Delegates to the shared Nominatim / Google Maps helper functions
  - Caches results keyed by coordinates rounded to 4 decimal places (~11m precision)
  - TTL: 1 hour (3600s) — long enough to eliminate re-calls for repeated drags
  - Cache backend: Django's default cache
"""

import logging
from django.core.cache import cache
# Note: Import your location detection function here
# from .detect_location import detect_customer_location

logger = logging.getLogger(__name__)

# Cache TTL in seconds (1 hour)
REVERSE_GEOCODE_CACHE_TTL = 3600

# Coordinate precision for cache key: 4 decimal places ≈ 11 m resolution
_COORD_PRECISION = 4


class AddressService:
    # ── Public API ─────────────────────────────────────────────────────────────

    @classmethod
    def reverse_geocode(cls, latitude: float, longitude: float, detect_location_func) -> dict | None:
        """
        Reverse geocode (lat, lng) to a structured address dict.

        Args:
            latitude: float
            longitude: float
            detect_location_func: function that geocodes lat/lng using Google/Nominatim

        Returns:
            {
                formatted_address: str,
                locality: str,        # road/suburb/neighbourhood
                city: str,
                state: str,
                pincode: str,
                country: str,
                latitude: float,
                longitude: float,
            }
        or None if geocoding fails.
        """
        try:
            lat = round(float(latitude), _COORD_PRECISION)
            lng = round(float(longitude), _COORD_PRECISION)
        except (ValueError, TypeError):
            return None

        cache_key = cls._cache_key(lat, lng)

        # ── Cache hit ──────────────────────────────────────────────────────────
        cached = cache.get(cache_key)
        if cached is not None:
            logger.debug("reverse_geocode cache HIT  (%s, %s)", lat, lng)
            return cached

        # ── Cache miss ─────────────────────────────────────────────────────────
        logger.debug("reverse_geocode cache MISS (%s, %s) — calling Geocoder", lat, lng)
        try:
            raw = detect_location_func(lat, lng, accuracy=None)
        except Exception as exc:
            logger.warning("reverse_geocode helper raised: %s", exc)
            return None

        if not raw:
            return None

        # Normalise into the shape
        result = {
            "formatted_address": raw.get("formatted_address", ""),
            "locality":          raw.get("area", ""),
            "city":              raw.get("city", ""),
            "state":             raw.get("state", ""),
            "pincode":           raw.get("pincode", ""),
            "country":           raw.get("country", ""),
            "latitude":          lat,
            "longitude":         lng,
        }

        cache.set(cache_key, result, timeout=REVERSE_GEOCODE_CACHE_TTL)
        return result

    # ── Private helpers ────────────────────────────────────────────────────────

    @staticmethod
    def _cache_key(lat: float, lng: float) -> str:
        return f"addr_revgeo:{lat:.4f}:{lng:.4f}"
