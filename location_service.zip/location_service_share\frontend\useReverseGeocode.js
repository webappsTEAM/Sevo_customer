/**
 * useReverseGeocode.js
 * Debounced reverse-geocoding hook
 *
 * Behaviour:
 *  • Debounces calls by DEBOUNCE_MS after coords change
 *  • Cancels any in-flight fetch when newer coords arrive (AbortController)
 *  • Exposes { address, loading, error } reactive state
 *  • On mount (or when initialCoords first set), fires immediately after
 *    DEBOUNCE_MS so the bottom sheet populates without needing a drag
 */

import { useState, useEffect, useRef, useCallback } from "react"

// Debounce window in ms — avoids firing on every intermediate idle after fast drags
const DEBOUNCE_MS = 500

const googleApiKey = "AIzaSyC-7JjgSXDrqNF1BMMnlvKtgRPS6_98uP8"

/**
 * @param {{ lat: number, lng: number } | null} coords
 * @param {function} [fallbackBackendFetch] Optional callback to fetch from your backend endpoint
 * @returns {{ address: object|null, loading: boolean, error: string|null }}
 *
 * address shape (when resolved):
 *   { formatted_address, locality, city, state, pincode, country, latitude, longitude }
 */
export function useReverseGeocode(coords, fallbackBackendFetch) {
  const [address, setAddress] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState(null)

  // Keep a ref to the current AbortController so we can cancel in-flight requests
  const abortRef   = useRef(null)
  const debounceRef = useRef(null)

  const fetchGeocode = useCallback(async (lat, lng, signal) => {
    setLoading(true)
    setError(null)

    try {
      let resolvedData = null

      // 1. Direct Google Maps Geocoding API (highest accuracy when API key is provided)
      if (googleApiKey && !signal.aborted) {
        try {
          const gRes = await fetch(
            `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${googleApiKey}`,
            { signal }
          )
          const gData = await gRes.json()
          if (gData.status === "OK" && gData.results && gData.results.length > 0) {
            const first = gData.results[0]
            const comps = first.address_components || []

            let streetNumber = ""
            let route = ""
            let sublocality = ""
            let locality = ""
            let city = ""
            let state = ""
            let pincode = ""
            let country = ""

            for (const c of comps) {
              const types = c.types || []
              if (types.includes("street_number")) streetNumber = c.long_name
              if (types.includes("route")) route = c.long_name
              if (types.includes("sublocality") || types.includes("sublocality_level_1")) sublocality = c.long_name
              if (types.includes("locality")) city = c.long_name
              if (types.includes("administrative_area_level_1")) state = c.long_name
              if (types.includes("postal_code")) pincode = c.long_name
              if (types.includes("country")) country = c.long_name
            }

            const cleanLoc = [streetNumber, route, sublocality].filter(Boolean).join(", ") || sublocality || route
            
            resolvedData = {
              formatted_address: first.formatted_address,
              locality: cleanLoc || sublocality || "Current Location",
              city: city || "",
              state: state || "",
              pincode: pincode || "",
              country: country || "India",
              latitude: lat,
              longitude: lng,
            }
          }
        } catch (e) { }
      }

      // 2. Try backend endpoint fallback if provided
      if (!resolvedData && !signal.aborted && fallbackBackendFetch) {
        try {
          const data = await fallbackBackendFetch(lat, lng, signal)
          if (data) {
            resolvedData = data
          }
        } catch (e) { }
      }

      // 3. Direct Google Maps Geocoding API fallback (retry with full parsing)
      if (!resolvedData && !signal.aborted && googleApiKey) {
        try {
          const gRes = await fetch(
            `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${googleApiKey}`,
            { signal }
          )
          const gData = await gRes.json()
          if (gData.status === "OK" && gData.results && gData.results.length > 0) {
            const first = gData.results[0]
            const comps = first.address_components || []
            let city = "", state = "", pincode = "", sublocality = ""
            for (const c of comps) {
              const types = c.types || []
              if (types.includes("sublocality") || types.includes("sublocality_level_1")) sublocality = c.long_name
              if (types.includes("locality")) city = c.long_name
              if (types.includes("administrative_area_level_1")) state = c.long_name
              if (types.includes("postal_code")) pincode = c.long_name
            }
            resolvedData = {
              formatted_address: first.formatted_address,
              locality: sublocality || first.formatted_address.split(",")[0] || "Current Location",
              city: city || "",
              state: state || "",
              pincode: pincode || "",
              latitude: lat,
              longitude: lng,
            }
          }
        } catch (e) { }
      }

      if (signal.aborted) return

      if (resolvedData) {
        setAddress(resolvedData)
      } else {
        setAddress({
          formatted_address: `GPS Location (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
          locality: `Current GPS Location`,
          city: "",
          state: "",
          pincode: "",
          latitude: lat,
          longitude: lng,
        })
      }
    } catch (err) {
      if (err?.name === "AbortError" || signal.aborted) return
      setAddress({
        formatted_address: `GPS Location (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
        locality: "Current GPS Location",
        city: "",
        state: "",
        pincode: "",
        latitude: lat,
        longitude: lng,
      })
    } finally {
      if (!signal.aborted) setLoading(false)
    }
  }, [fallbackBackendFetch])

  useEffect(() => {
    if (!coords) return

    const { lat, lng } = coords

    // Cancel any pending debounce
    clearTimeout(debounceRef.current)

    // Cancel any in-flight request
    if (abortRef.current) {
      abortRef.current.abort()
    }

    debounceRef.current = setTimeout(() => {
      const controller = new AbortController()
      abortRef.current = controller
      fetchGeocode(lat, lng, controller.signal)
    }, DEBOUNCE_MS)

    // Cleanup: cancel on unmount or coords change before timer fires
    return () => {
      clearTimeout(debounceRef.current)
      if (abortRef.current) abortRef.current.abort()
    }
  }, [coords?.lat, coords?.lng, fetchGeocode])

  return { address, loading, error }
}
