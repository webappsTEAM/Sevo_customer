# Location & Geocoding Service Share

This package contains the location and geocoding services used in CalTrack (both Frontend and Backend implementations), along with the configured Google Maps API Key.

---

## 🔑 Google Maps API Key
```env
GOOGLE_MAPS_API_KEY=AIzaSyC-7JjgSXDrqNF1BMMnlvKtgRPS6_98uP8
```
*Note: Make sure to restrict this key in the Google Cloud Console to your application's domain/bundle ID for production use.*

---

## 📁 Shared Components

### 1. Frontend Services (`/frontend`)
* **`geocoding.js`**: Pure JavaScript geocoding helper.
  * Tries Google Maps Geocoding API first (if `GOOGLE_MAPS_API_KEY` is provided).
  * If the key is not provided, or fails/gets rate-limited, it gracefully falls back to **Nominatim (OpenStreetMap)** (which is free and does not require an API key).
* **`useLocation.js`**: React hook / standard JS helper for device tracking.
  * Uses the browser `navigator.geolocation` API to retrieve coordinates with target accuracy checks, timeouts, and tracking.
  * Includes `calculateDistance(lat1, lon1, lat2, lon2)` using the Haversine formula (returns distance in meters).
* **`useReverseGeocode.js`**: React hook for debouncing and fetching reverse geocode details.
  * Avoids hitting the API on every intermediate point during continuous map drags.
  * Handles aborting in-flight request signals when new coordinates arrive.

### 2. Backend Services (`/backend`)
* **`detect_location.py`**: A pure, stateless Python function (`detect_customer_location`) for reverse geocoding coordinates.
  * Uses the standard Python `urllib` library (no external `requests` package required).
  * Implements Google Maps API reverse-geocoding, falling back to Nominatim (OpenStreetMap) if no key is configured or an error occurs.
* **`address_service.py`**: A Django-based cached address service.
  * Caches geocoding responses for 1 hour keyed by coordinates rounded to 4 decimal places (~11m resolution) to optimize API usage and speed up repeated map interactions.

---

## ⚙️ Configuration & Environment Setup

### Frontend Integration (Vite / CRA / React Native)
Expose the Google Maps key in your frontend environment variables:
* For **Vite**: Add `VITE_GOOGLE_MAPS_API_KEY=AIzaSyC-7JjgSXDrqNF1BMMnlvKtgRPS6_98uP8` to `.env` and load it via `import.meta.env.VITE_GOOGLE_MAPS_API_KEY`.
* For **Create React App**: Add `REACT_APP_GOOGLE_MAPS_API_KEY=AIzaSyC-7JjgSXDrqNF1BMMnlvKtgRPS6_98uP8` and load via `process.env.REACT_APP_GOOGLE_MAPS_API_KEY`.

### Backend Integration (Django / Flask / Python)
Expose the Google Maps API key in your server environment:
```bash
export GOOGLE_MAPS_API_KEY="AIzaSyC-7JjgSXDrqNF1BMMnlvKtgRPS6_98uP8"
```
Or define it in your Django `.env` / `settings.py`.
